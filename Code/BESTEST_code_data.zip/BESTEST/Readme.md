Description of the folders and files:

+ data/ contains the directed graph
+ all.ipynb contains the code and the results for the BESTest run on the network with all edges (with 100 times 3 iterations)
+ reciprocal.ipynb contains the code and the results for the BESTest run on the network with reciprocal edges (with 100 times 3 iterations)
+ out/ contains the output files with the p-values
+ replication/ contains the code of the replication and the data for it (the results are present in the report, we have received them from Claudio)

To run the notebooks in full, in reciprocal.ipynb and all.ipynb remove the parameters N and n_conf (the functions have correct defaults).
